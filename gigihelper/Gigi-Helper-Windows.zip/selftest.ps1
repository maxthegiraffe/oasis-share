# gigi.ps1 -SelfTest: the runner's pure parts, checked on Windows before anything runs (prints ok/FAIL per check, exits 0
# only when all pass: gigi.ps1 reads $script:fails). Dot-sourced by gigi.ps1 after lines.ps1 and steps.ps1.
$script:fails = 0
function Check([string]$name, [scriptblock]$test) {
  $ok = $false
  try { $ok = [bool](& $test) } catch { Write-Host "  ($($_.Exception.Message))" }
  if ($ok) { Write-Host "ok $name" } else { Write-Host "FAIL $name"; $script:fails++ }
}

Check 'code is normalised' { (ConvertTo-GigiCode ' gigi-ab23-cd45 ') -eq 'GIGI-AB23-CD45' }
Check 'code without dashes or prefix' { (ConvertTo-GigiCode 'code: ab23cd45') -eq 'GIGI-AB23-CD45' }
Check 'code with a letter it never uses is refused' { $null -eq (ConvertTo-GigiCode 'GIGI-AB12-CD34') }
Check 'garbage is refused' { $null -eq (ConvertTo-GigiCode 'hello') }
Check 'device code from gh' { (Get-DeviceCode '! First copy your one-time code: 1A2B-3C4D') -eq '1A2B-3C4D' }
Check 'no device code yet' { $null -eq (Get-DeviceCode 'Press Enter to open github.com') }
Check '8 steps with the interview' { (Get-GigiSteps $true).Count -eq 8 }
Check 'bootcamp: 6 steps then all_set' { $s = Get-GigiSteps $false; $s.Count -eq 7 -and $s[-1].id -eq 'all_set' -and $s[5].id -eq 'kit_install_prompt' }
Check 'step ids match the Mac' {
  ((Get-GigiSteps $true) | ForEach-Object { $_.id }) -join ',' -eq 'before_you_start,download_kit,install_claude_app,tools,superpowers_plugin,kit_install_prompt,setup_interview,see_it_work'
}
Check 'kit follows Documents (OneDrive too)' { (Get-KitPath).StartsWith([Environment]::GetFolderPath('MyDocuments')) -and (Get-KitPath).EndsWith('\Claude Code\agentic-business-os-pkg') }
Check 'a taken port is skipped' {
  $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 47331)
  $l.Start()
  try { (Get-FreePort 47331) -eq 47332 } finally { $l.Stop() }
}
Check 'her lines have no Mac words or dashes' {
  $all = (Get-AllLineText) -join "`n"
  $dash = '[' + [char]0x2014 + [char]0x2013 + ']'
  -not ($all -cmatch "Mac|Terminal|Homebrew|\btap ") -and -not ($all -match $dash)
}
Check 'redeem errors read right' { (Get-RedeemLine 'other_mac').say -like '*another computer*' -and (Get-RedeemLine 'nonsense').say -like "*doesn't look right*" }
Check 'the Claude app link carries the kit folder' { (Get-CodeLink '/setup') -like 'claude://code/new?q=%2Fsetup&folder=*agentic-business-os-pkg&source=gigi' }
Check 'quotes survive the trip to claude.exe' { (ConvertTo-NativeArg 'say "hi"') -eq 'say \"hi\"' }
Check 'a Store shortcut is not a program' { $c = Get-Cmd python3; -not $c -or $c.Source -notlike '*\WindowsApps\*' }
Check 'the hook command is PowerShell' { (Get-HookCommand) -like 'powershell*claude-asks.jsonl*' }

if ($script:fails -gt 0) { Write-Host "$script:fails failed" } else { Write-Host 'all ok' }

# gigi.ps1 -SelfTest: the runner's pure parts, checked on Windows before anything runs (prints ok/FAIL per check, exits 0
# only when all pass: gigi.ps1 reads $script:fails). Dot-sourced by gigi.ps1 after lines.ps1 and steps.ps1.
$script:fails = 0
function Check([string]$name, [scriptblock]$test) {
  $ok = $false
  try { $ok = [bool](& $test) } catch { Write-Host "  ($($_.Exception.Message))" }
  if ($ok) { Write-Host "ok $name" } else { Write-Host "FAIL $name"; $script:fails++ }
}

Check 'code is normalised' { (ConvertTo-GigiCode ' gigi-ab23-cd45 ') -eq 'GIGI-AB23-CD45' }
Check 'code without dashes or prefix' { (ConvertTo-GigiCode 'code: ab23cd45') -eq 'GIGI-AB23-CD45' }
Check 'code with a letter it never uses is refused' { $null -eq (ConvertTo-GigiCode 'GIGI-AB12-CD34') }
Check 'garbage is refused' { $null -eq (ConvertTo-GigiCode 'hello') }
Check 'device code from gh' { (Get-DeviceCode '! First copy your one-time code: 1A2B-3C4D') -eq '1A2B-3C4D' }
Check 'no device code yet' { $null -eq (Get-DeviceCode 'Press Enter to open github.com') }
Check '8 steps with the interview' { (Get-GigiSteps $true).Count -eq 8 }
Check 'bootcamp: 5 steps then all_set, no kit install' { $s = Get-GigiSteps $false; $s.Count -eq 6 -and $s[-1].id -eq 'all_set' -and $s[4].id -eq 'superpowers_plugin' -and -not ($s.id -contains 'kit_install_prompt') }
Check 'step ids match the Mac' {
  ((Get-GigiSteps $true) | ForEach-Object { $_.id }) -join ',' -eq 'before_you_start,download_kit,install_claude_app,tools,superpowers_plugin,kit_install_prompt,setup_interview,see_it_work'
}
Check 'kit follows Documents (OneDrive too)' { (Get-KitPath).StartsWith([Environment]::GetFolderPath('MyDocuments')) -and (Get-KitPath).EndsWith('\Claude Code\agentic-business-os-pkg') }
Check 'a taken port is skipped' {
  $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 47331)
  $l.Start()
  try { (Get-FreePort 47331) -eq 47332 } finally { $l.Stop() }
}
Check 'a Bootcamp finish tells her it ends here, with no interview' { $n = Get-FinishedNote 6 $false; $n -like '*All 6 steps*' -and $n -like '*never send them to Claude*' -and $n -notlike '*Agent OS is set up*' }
Check 'an AgentOS finish says Agent OS is set up' { (Get-FinishedNote 8 $true) -eq 'HANDS finished: All 8 steps are done. Agent OS is set up on their PC.' }
Check 'her lines have no Mac words or dashes' {
  $all = (Get-AllLineText) -join "`n"
  $dash = '[' + [char]0x2014 + [char]0x2013 + ']'
  -not ($all -cmatch "Mac|Terminal|Homebrew|\btap ") -and -not ($all -match $dash)
}
Check 'redeem errors read right' { (Get-RedeemLine 'other_mac').say -like '*another computer*' -and (Get-RedeemLine 'nonsense').say -like "*doesn't look right*" }
Check 'the Claude app link carries the kit folder' { (Get-CodeLink '/setup') -like 'claude://code/new?q=%2Fsetup&folder=*agentic-business-os-pkg&source=gigi' }
Check 'quotes survive the trip to claude.exe' { (ConvertTo-NativeArg 'say "hi"') -eq 'say \"hi\"' }
Check 'a Store shortcut is not a program' { $c = Get-Cmd python3; -not $c -or $c.Source -notlike '*\WindowsApps\*' }
Check 'the hook command is PowerShell' { (Get-HookCommand) -like 'powershell*claude-asks.jsonl*' }

# Final review fixes (2026-11-13)
$tmp = Join-Path $env:TEMP ('gigi-selftest-' + [guid]::NewGuid())
$null = New-Item -ItemType Directory -Path $tmp
Check 'a broken settings file is never read as empty' { $f = Join-Path $tmp 'bad.json'; Set-Content $f '{bad'; try { $null = Read-Json $f; $false } catch { $true } }
Check 'a settings file is backed up before it is rewritten' {
  $f = Join-Path $tmp 'ok.json'; Set-Content $f '{"a":1}'
  Write-Json ([pscustomobject]@{ b = 2 }) $f
  (Test-Path "$f.gigi-backup") -and ((Get-Content $f -Raw | ConvertFrom-Json).b -eq 2)
}
Check 'the device id lives in the registry, so Quit never loses it' {
  $keep = $env:GIGI_DEVICE; $env:GIGI_DEVICE = $null   # the test machine pins one; this checks the real path
  try { $a = Get-DeviceId; $b = Get-DeviceId } finally { $env:GIGI_DEVICE = $keep }
  $a -eq $b -and $a -match '^[0-9a-f-]{36}$' -and (Get-ItemProperty 'HKCU:\Software\Grateful Giraffes\Gigi Helper').Device -eq $a
}
Check 'an existing python.exe gets a python3 beside it' {
  $d = Join-Path $tmp 'py'; $null = New-Item -ItemType Directory -Path $d; Set-Content (Join-Path $d 'python.exe') 'x'
  Add-Python3Alias (Join-Path $d 'python.exe'); Test-Path (Join-Path $d 'python3.exe')
}
Check 'a request body is read as bytes (an en dash in a code)' {
  $body = '{"do":"unlock","code":"GIGI' + [char]0x2013 + 'AB23-CD45"}'
  $b = [Text.Encoding]::UTF8.GetBytes($body)
  $head = [Text.Encoding]::ASCII.GetBytes("POST /act HTTP/1.1`r`nContent-Type: application/json`r`nContent-Length: $($b.Length)`r`n`r`n")
  $ms = New-Object IO.MemoryStream; $ms.Write($head, 0, $head.Length); $ms.Write($b, 0, $b.Length); $ms.Position = 0
  $r = Read-HttpRequest $ms
  $r.path -eq '/act' -and $r.body -eq $body
}
Check 'a connection that sends nothing is dropped' { $null -eq (Read-HttpRequest (New-Object IO.MemoryStream)) }
Check 'her card is reopened only with Edge, and at most 3 times' {
  (Test-ShouldReopen 15 30 0 $true) -and -not (Test-ShouldReopen 15 30 0 $false) -and -not (Test-ShouldReopen 15 30 3 $true) -and -not (Test-ShouldReopen 15 10 0 $true) -and -not (Test-ShouldReopen 5 30 0 $true)
}
Check 'a crash is written down' { $script:Dir = $tmp; Show-Fatal 'boom' -NoBox; (Get-Content (Join-Path $tmp 'gigi.log') -Raw) -match 'fatal: boom' }
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

if ($script:fails -gt 0) { Write-Host "$script:fails failed" } else { Write-Host 'all ok' }

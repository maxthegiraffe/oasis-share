# Gigi Helper for Windows (Max, 2026-11-12: "we have to create gigi for windows now"). Started hidden by win.ps1:
#   powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File gigi.ps1 -Code GIGI-XXXX-XXXX
# It unlocks her with the code (the gigi-helper Worker's /redeem, unchanged), runs the Windows steps in a background
# runspace (runner.ps1), serves her card on 127.0.0.1 and opens it in a small Edge window. The card does her voice.
param([string]$Code = '', [switch]$SelfTest, [switch]$Forget)

$ErrorActionPreference = 'Stop'
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $AppDir 'lines.ps1')
. (Join-Path $AppDir 'steps.ps1')
. (Join-Path $AppDir 'core.ps1')
if ($SelfTest) { . (Join-Path $AppDir 'selftest.ps1'); if ($script:fails -gt 0) { exit 1 } else { exit 0 } }

$HomeUrl = 'https://gigi-helper.gigi-grateful.workers.dev'
$null = New-Item -ItemType Directory -Force -Path $Dir
$StateFile = Join-Path $Dir 'state.json'
if ($Forget) { Remove-Item $StateFile -ErrorAction SilentlyContinue; exit 0 }

# Anything that stops her is written down, and she says so in a box (her window may never have opened).
trap { Show-Fatal ([string]$_); exit 1 }

$mutex = New-Object Threading.Mutex($false, 'Local\GigiHelperWindows')
if (-not $mutex.WaitOne(0)) { exit 0 }   # she's already running (win.ps1 stops an older one first)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -Namespace Gigi -Name User32 -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SetWindowPos(System.IntPtr h, System.IntPtr after, int x, int y, int cx, int cy, uint flags);
[DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int cmd);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(System.IntPtr h);
'@

# ---------- what she remembers on this PC ----------

function Write-Log([string]$t) { try { [IO.File]::AppendAllText((Join-Path $Dir 'gigi.log'), "$(Get-Date -Format s) $t`r`n") } catch { } }

function Read-State {
  $d = $null
  try { $d = Read-Json $StateFile } catch { $d = New-Object PSObject }   # a broken state file: start fresh, the code still works here
  Set-Prop $d 'device' (Get-DeviceId)
  $d
}
function Save-State { Write-Json $State $StateFile }

# The pass, encrypted for this Windows user (DPAPI), as the Mac keeps it in the Keychain.
function Get-Pass {
  if (-not $State.pass) { return $null }
  try {
    $sec = ConvertTo-SecureString $State.pass
    [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  } catch { $null }
}
function Set-Pass([string]$p) {
  if ($p) { Set-Prop $State 'pass' (ConvertTo-SecureString $p -AsPlainText -Force | ConvertFrom-SecureString) } else { Set-Prop $State 'pass' $null }
}

$State = Read-State
Save-State

# The kit's prompts, as files the steps read.
$prompts = Get-Content -Raw -Encoding UTF8 (Join-Path $AppDir 'prompts.json') | ConvertFrom-Json
foreach ($k in 'install_prompt', 'first_prompt') { [IO.File]::WriteAllText((Join-Path $Dir "$k.txt"), [string]$prompts.$k, (New-Object Text.UTF8Encoding($false))) }

# ---------- the shared state the card reads ----------

$S = [hashtable]::Synchronized(@{})
$S.stage = 'code'; $S.line = $Lines.code; $S.second = $null; $S.notes = New-Object Collections.ArrayList; $S.seq = 0
$S.steps = @(); $S.stepsVersion = 0; $S.at = 0; $S.stepStart = Get-Date; $S.waiting = $false; $S.handoff = $null
$S.deviceCode = $null; $S.inBrowser = $false; $S.side = 'left'; $S.doing = $null; $S.asking = $false; $S.answer = $false
$S.askUrl = $null; $S.consolePid = 0; $S.showApp = $false; $S.lastNote = ''; $S.quit = $false; $S.saveNeeded = $false
$S.name = [string]$State.name; $S.interview = ($State.interview -ne $false); $S.micOk = $State.micOk
$S.confirmed = @($State.confirmed | Where-Object { $_ }); $S.firstLine = ''

function Set-Steps { $S.steps = @(Get-GigiSteps $S.interview | ForEach-Object { @{ id = $_.id; title = $_.title; state = 'todo' } }) }

function Start-Running {
  $S.firstLine = Get-FirstLine ([bool]$State.voiceStarted) $S.interview
  $S.line = $Lines.running
  $S.stage = 'running'
}

function Set-Unlocked {
  $S.home = $HomeUrl; $S.pass = Get-Pass   # for the step reports to Gigi's cloud (runner.ps1)
  Set-Steps
  if ($null -eq $S.micOk) { $S.stage = 'mic'; $S.line = $Lines.mic } else { Start-Running }
}

function Invoke-Redeem([string]$raw) {
  $c = ConvertTo-GigiCode $raw
  if (-not $c) { $S.stage = 'code'; $S.line = Get-RedeemLine 'unknown'; return }
  $S.stage = 'unlocking'; $S.line = $Lines.unlocking
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $body = @{ code = $c; device = $State.device; os = 'windows' } | ConvertTo-Json -Compress
    $r = Invoke-RestMethod -Method Post -Uri "$HomeUrl/redeem" -ContentType 'application/json' -Body $body -TimeoutSec 20 -UseBasicParsing
  } catch {
    $why = 'offline'
    $resp = $_.Exception.Response
    if ($resp) { try { $why = ((New-Object IO.StreamReader($resp.GetResponseStream())).ReadToEnd() | ConvertFrom-Json).error } catch { $why = 'unknown' } }
    Write-Log "redeem refused: $why"
    $S.stage = 'code'; $S.line = Get-RedeemLine $why
    return
  }
  try {
    Set-Pass $r.pass
    Set-Prop $State 'name' ([string]$r.name)
    Set-Prop $State 'interview' ($r.interview -ne $false)
    Save-State
  } catch {
    Write-Log "saving the pass failed: $($_.Exception.Message)"
    $S.stage = 'code'; $S.line = Get-RedeemLine 'offline'
    return
  }
  $S.name = [string]$r.name; $S.interview = ($r.interview -ne $false)
  Write-Log "unlocked (interview $($S.interview))"
  Set-Unlocked
}

# ---------- the card's server ----------

$Port = Get-FreePort 47321
$Key = -join ((1..24) | ForEach-Object { '{0:x}' -f (Get-Random -Maximum 16) })
$Origin = "http://127.0.0.1:$Port"
$CardDir = Join-Path $AppDir 'card'
$Types = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.mp4' = 'video/mp4'; '.json' = 'application/json' }

function Send([Net.Sockets.NetworkStream]$ns, [int]$code, [byte[]]$body, [string]$type, [string]$extra = '') {
  $reason = @{ 200 = 'OK'; 206 = 'Partial Content'; 401 = 'Unauthorized'; 403 = 'Forbidden'; 404 = 'Not Found'; 502 = 'Bad Gateway' }[$code]
  $head = "HTTP/1.1 $code $reason`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n$extra`r`n"
  $h = [Text.Encoding]::ASCII.GetBytes($head)
  $ns.Write($h, 0, $h.Length)
  if ($body.Length) { $ns.Write($body, 0, $body.Length) }
}
function Send-Json($ns, [int]$code, $obj) { Send $ns $code ([Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Depth 8 -Compress))) 'application/json; charset=utf-8' }

function Get-CardState([int]$since) {
  [Threading.Monitor]::Enter($S.SyncRoot)
  try {
    $notes = @($S.notes | Where-Object { $_.seq -gt $since })
    @{
      stage = $S.stage; line = $S.line; second = $S.second; steps = @($S.steps); at = $S.at
      secs = [int]((Get-Date) - $S.stepStart).TotalSeconds; waiting = $S.waiting; handoff = $S.handoff; doing = $S.doing
      deviceCode = $S.deviceCode; inBrowser = $S.inBrowser; side = $S.side; asking = $S.asking; lastNote = $S.lastNote
      name = $S.name; interview = $S.interview; micOk = $S.micOk; firstLine = $S.firstLine; notes = $notes
    }
  } finally { [Threading.Monitor]::Exit($S.SyncRoot) }
}

function Invoke-Act($b) {
  Write-Log "act $($b.do)"
  switch ($b.do) {
    'unlock' { Invoke-Redeem ([string]$b.code) }
    'mic' { $S.micOk = [bool]$b.ok; Set-Prop $State 'micOk' ([bool]$b.ok); Save-State; if ($S.stage -eq 'mic') { Start-Running } }
    'voice' {
      Set-Prop $State 'voiceStarted' $true; Save-State; $S.firstLine = Get-FirstLine $true $S.interview
      if ($b.conv) { Send-Report $HomeUrl (Get-Pass) @{ kind = 'voice'; conv = [string]$b.conv } }
    }
    'confirm' { if ($S.asking) { $S.answer = $true } }
    'help' {
      if ($S.askUrl) { Start-Process $S.askUrl }
      [Threading.Monitor]::Enter($S.SyncRoot)
      try { $S.seq = $S.seq + 1; $null = $S.notes.Add(@{ seq = $S.seq; text = $Say.signUpNote; speak = $true }) } finally { [Threading.Monitor]::Exit($S.SyncRoot) }
    }
    'stop' { if ($S.stage -eq 'running') { $S.stage = 'paused'; $S.line = $Lines.paused } }
    'resume' { if ($S.stage -eq 'paused') { Start-Running } }
    'retry' { if ($S.stage -eq 'failed') { Start-Running } }
    'show' {
      if ($S.showApp) { try { Open-ClaudeApp } catch { } }
      elseif ($S.consolePid) {
        $h = (Get-Process -Id $S.consolePid -ErrorAction SilentlyContinue).MainWindowHandle
        if ($h -and $h -ne [IntPtr]::Zero) { [void][Gigi.User32]::ShowWindow($h, 9); [void][Gigi.User32]::SetForegroundWindow($h) }
      }
    }
    'quit' { $S.quit = $true; $script:Uninstall = ($S.stage -eq 'done') }
  }
}

# GET /voice: a fresh signed link to her Windows agent. The pass never leaves this process.
function Get-VoiceLink($ns) {
  $p = Get-Pass
  if (-not $p) { return Send-Json $ns 401 @{ error = 'pass' } }
  try {
    $r = Invoke-RestMethod -Uri "$HomeUrl/voice?t=$([Uri]::EscapeDataString($p))&os=windows" -TimeoutSec 20 -UseBasicParsing
    Send-Json $ns 200 @{ signed_url = $r.signed_url }
  } catch {
    $code = 0
    if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
    if ($code -eq 401 -or $code -eq 403) {
      # Her 30-day pass ran out, or the code was put on hold: back to the code box; the code still works on this PC.
      $why = 'expired'
      try { if (((New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() | ConvertFrom-Json).error -eq 'on_hold') { $why = 'on_hold' } } catch { }
      Set-Pass $null; Save-State
      $S.stage = 'code'; $S.line = Get-RedeemLine $why
    }
    Send-Json $ns 502 @{ error = 'voice' }
  }
}

function Send-File($ns, [string]$rel, [string]$range) {
  $full = [IO.Path]::GetFullPath((Join-Path $CardDir $rel))
  if (-not $full.StartsWith($CardDir, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Leaf)) {
    return Send $ns 404 ([Text.Encoding]::UTF8.GetBytes('not found')) 'text/plain'
  }
  $bytes = [IO.File]::ReadAllBytes($full)
  $type = $Types[[IO.Path]::GetExtension($full).ToLowerInvariant()]
  if (-not $type) { $type = 'application/octet-stream' }
  $m = [regex]::Match([string]$range, 'bytes=(\d+)-(\d*)')
  if ($m.Success) {
    $from = [int64]$m.Groups[1].Value
    $to = if ($m.Groups[2].Value) { [int64]$m.Groups[2].Value } else { $bytes.Length - 1 }
    $to = [Math]::Min($to, $bytes.Length - 1)
    $part = New-Object byte[] ($to - $from + 1)
    [Array]::Copy($bytes, $from, $part, 0, $part.Length)
    return Send $ns 206 $part $type "Accept-Ranges: bytes`r`nContent-Range: bytes $from-$to/$($bytes.Length)`r`n"
  }
  Send $ns 200 $bytes $type "Accept-Ranges: bytes`r`n"
}

function Invoke-Client([Net.Sockets.TcpClient]$c) {
  $ns = $c.GetStream()
  $ns.ReadTimeout = 2000
  $req = Read-HttpRequest $ns
  if (-not $req) { return }
  $h = $req.headers
  $body = $req.body
  $u = [Uri]("$Origin" + $req.target)
  $path = $u.AbsolutePath
  if ($path -in '/state', '/act', '/voice') {
    if ($h['x-gigi-key'] -ne $Key -or ($h['origin'] -and $h['origin'] -ne $Origin)) { return Send-Json $ns 403 @{ error = 'key' } }
    if ($path -eq '/state') {
      $since = 0; [void][int]::TryParse(([Web.HttpUtility]::ParseQueryString($u.Query))['since'], [ref]$since)
      return Send-Json $ns 200 (Get-CardState $since)
    }
    if ($path -eq '/voice') { return Get-VoiceLink $ns }
    $b = $null; try { $b = $body | ConvertFrom-Json } catch { }
    if ($b) { Invoke-Act $b }
    return Send-Json $ns 200 @{ ok = $true }
  }
  $rel = if ($path -eq '/') { 'index.html' } else { [Uri]::UnescapeDataString($path.TrimStart('/')) }
  Send-File $ns $rel $h['range']
}

# ---------- her card in Edge ----------

function Find-Edge {
  foreach ($root in 'HKLM:', 'HKCU:') {
    try { $p = (Get-ItemProperty "$root\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction Stop).'(default)'; if ($p -and (Test-Path $p)) { return $p } } catch { }
  }
  foreach ($p in "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") { if (Test-Path $p) { return $p } }
  $null
}

$EdgeProfile = Join-Path $Dir 'edge'
$script:HasEdge = [bool](Find-Edge)
$script:Reopens = 0
function Open-Card {
  $url = "$Origin/?k=$Key"
  $edge = Find-Edge
  Write-Log "opening her card ($edge)"
  if ($edge) {
    $a = @("--app=$url", "--user-data-dir=`"$EdgeProfile`"", '--no-first-run', '--no-default-browser-check',
      '--autoplay-policy=no-user-gesture-required', '--window-size=440,760', '--window-position=0,0', '--disable-features=Translate')
    $a += @(([string]$env:GIGI_EDGE_FLAGS).Split(' ') | Where-Object { $_ })   # tests only: a fake mic on a PC with none
    Start-Process -FilePath $edge -ArgumentList $a
  } else { Start-Process $url }
  $script:CardOpened = Get-Date
}

function Get-CardWindow {
  Get-Process msedge -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -eq 'Gigi' -and $_.MainWindowHandle -ne [IntPtr]::Zero } | Select-Object -First 1
}

function Stop-Card {
  Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*$EdgeProfile*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

# Her card stays on top, at the left edge, or the right edge while a browser sign-in needs the middle of the screen.
$script:placedSide = ''
$script:lastSeenCard = Get-Date
function Watch-Card {
  $w = Get-CardWindow
  if ($w) {
    $script:lastSeenCard = Get-Date
    $script:Reopens = 0
    if ($script:placedSide -ne $S.side) {
      $area = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
      $x = if ($S.side -eq 'right') { $area.Right - 456 } else { $area.Left }
      [void][Gigi.User32]::SetWindowPos($w.MainWindowHandle, [IntPtr](-1), $x, $area.Top, 0, 0, 0x0001 -bor 0x0010)
      $script:placedSide = $S.side
    }
  } elseif (Test-ShouldReopen ((Get-Date) - $script:lastSeenCard).TotalSeconds ((Get-Date) - $script:CardOpened).TotalSeconds $script:Reopens $script:HasEdge) {
    # The card was closed without Quit: it comes back.
    $script:placedSide = ''
    $script:Reopens++
    Write-Log "her card was closed: reopening ($script:Reopens)"
    Open-Card
  }
}

# Claude Code's permission prompts (the hook writes them here): she says what each one means.
$script:asksRead = 0
function Watch-Asks {
  $f = Join-Path $Dir 'claude-asks.jsonl'
  if (-not (Test-Path $f)) { return }
  $len = (Get-Item $f).Length
  if ($len -le $script:asksRead) { return }
  $fs = [IO.File]::Open($f, 'Open', 'Read', 'ReadWrite')
  try { [void]$fs.Seek($script:asksRead, 'Begin'); $text = (New-Object IO.StreamReader($fs)).ReadToEnd() } finally { $fs.Close() }
  $script:asksRead = $len
  foreach ($line in ($text -split "`r?`n")) {
    try { $m = ($line | ConvertFrom-Json).message } catch { continue }
    if (-not $m -or $m -notmatch 'permission') { continue }
    $note = "HANDS need_person: Claude is asking for approval: `"$m`" Tell them what that means in plain words, in one or two short sentences. If it's a normal part of the setup, tell them it's okay to approve. If it looks like it would delete things or touch anything outside the kit, tell them to say no and ask you."
    [Threading.Monitor]::Enter($S.SyncRoot)
    try { $S.seq = $S.seq + 1; $null = $S.notes.Add(@{ seq = $S.seq; text = $note; speak = $true }) } finally { [Threading.Monitor]::Exit($S.SyncRoot) }
  }
}

# ---------- start ----------

Write-Log "start (port $Port)"
Add-Type -AssemblyName System.Web
if (Test-Path (Join-Path $Dir 'claude-asks.jsonl')) { $script:asksRead = (Get-Item (Join-Path $Dir 'claude-asks.jsonl')).Length }
if ($Code) { Invoke-Redeem $Code }
elseif (Get-Pass) { Set-Unlocked }

$rs = [RunspaceFactory]::CreateRunspace()
$rs.ApartmentState = 'STA'
$rs.Open()
$rs.SessionStateProxy.SetVariable('S', $S)
$rs.SessionStateProxy.SetVariable('AppDir', $AppDir)
$ps = [PowerShell]::Create()
$ps.Runspace = $rs
$null = $ps.AddScript("Set-ExecutionPolicy -Scope Process Bypass -Force; . '$((Join-Path $AppDir 'runner.ps1') -replace "'", "''")'")
$job = $ps.BeginInvoke()

$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $Port)
$listener.Start()
$script:CardOpened = Get-Date
Open-Card
$script:Uninstall = $false
$tick = Get-Date
$waiting = New-Object Collections.ArrayList   # connections that haven't sent a request yet (Edge opens spares)
try {
  while (-not $S.quit) {
    while ($listener.Pending()) { $null = $waiting.Add(@{ c = $listener.AcceptTcpClient(); t = Get-Date }) }
    $served = $false
    foreach ($e in @($waiting)) {
      if ($e.c.Available -gt 0) {
        $waiting.Remove($e); $served = $true
        try { Invoke-Client $e.c } catch { Write-Log "http: $($_.Exception.Message)" } finally { $e.c.Close() }
      } elseif (((Get-Date) - $e.t).TotalSeconds -gt 20) { $waiting.Remove($e); $e.c.Close() }
    }
    if (-not $served) { Start-Sleep -Milliseconds 20 }
    if (((Get-Date) - $tick).TotalSeconds -ge 2) {
      $tick = Get-Date
      try { Watch-Card; Watch-Asks } catch { Write-Log "watch: $($_.Exception.Message)" }
      if ($S.saveNeeded) { $S.saveNeeded = $false; Set-Prop $State 'confirmed' @($S.confirmed); Save-State }
      if ($job.IsCompleted) { Write-Log ('runner ended: ' + (($ps.Streams.Error | Select-Object -First 3) -join ' | ')); break }
    }
  }
} finally {
  $listener.Stop()
  Write-Log 'bye'
  Stop-Card
  if ($script:Uninstall) {
    # Setup is done and they clicked Quit: she tidies herself away (her files, her Edge profile). Their kit stays.
    Start-Sleep -Seconds 2
    Start-Process -WindowStyle Hidden -FilePath 'cmd.exe' -ArgumentList "/c timeout /t 3 >nul & rmdir /s /q `"$Dir`""
  }
  $mutex.ReleaseMutex()
  [Environment]::Exit(0)
}

# The Windows steps (the Mac's Sources/Steps.swift for a PC). Only these commands ever run; nothing an AI writes is
# executed. Every install is for this user only: no admin, no UAC box. Installer sources checked 2026-11-13:
#   Claude app   https://claude.ai/api/desktop/win32/<x64|arm64>/msix/latest/redirect (signed MSIX, Add-AppxPackage)
#   Git          PortableGit-<v>-<64-bit|arm64>.7z.exe from github.com/git-for-windows/git releases (self-extracting)
#   Python       python.org 3.12.10 <amd64|arm64> installer, InstallAllUsers=0 PrependPath=1
#   GitHub CLI   gh_<v>_windows_<amd64|arm64>.zip from github.com/cli/cli releases
#   Claude Code  https://claude.ai/install.ps1
# Phase kinds (as Steps.swift): run, console (Terminal on the Mac), ask, wait, status, device.

$KitZip = 'https://drive.google.com/uc?export=download&id=1nHI493S7JuJMEUi8CcA4mgmaMPaTVPpO'
$PythonVersion = '3.12.10'
$Dir = Join-Path $env:LOCALAPPDATA 'Gigi Helper'
$Programs = Join-Path $env:LOCALAPPDATA 'Programs'
$GitHubDevice = 'https://github.com/login/device'

# ---------- pure helpers (checked by -SelfTest) ----------

function ConvertTo-GigiCode([string]$text) {
  $s = ($text.ToUpperInvariant() -replace '[^A-Z0-9]', '')
  if ($s.StartsWith('CODE')) { $s = $s.Substring(4) }
  if ($s.StartsWith('GIGI')) { $s = $s.Substring(4) }
  if ($s -cnotmatch '^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{8}$') { return $null }
  'GIGI-' + $s.Substring(0, 4) + '-' + $s.Substring(4, 4)
}

function Get-DeviceCode([string]$text) {
  $m = [regex]::Match([string]$text, '(?<![A-Z0-9])[A-Z0-9]{4}-[A-Z0-9]{4}(?![A-Z0-9])')
  if ($m.Success) { return $m.Value }
  $null
}

function Get-KitPath { Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Claude Code\agentic-business-os-pkg' }

function Get-FreePort([int]$From = 47321) {
  for ($p = $From; $p -lt $From + 50; $p++) {
    $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
    try { $l.Start(); $l.Stop(); return $p } catch { }
  }
  throw 'no free port'
}

# PowerShell 5.1 hands a string to a program without escaping its quotes; claude.exe reads \" as a quote.
function ConvertTo-NativeArg([string]$s) { $s -replace '(\\*)"', '$1$1\"' }

function Get-CodeLink([string]$prompt) {
  $q = [Uri]::EscapeDataString($prompt)
  $f = [Uri]::EscapeDataString((Get-KitPath))
  "claude://code/new?q=$q&folder=$f&source=gigi"
}

function Get-HookCommand {
  $f = Join-Path $Dir 'claude-asks.jsonl'
  "powershell -NoProfile -Command `"[Console]::In.ReadToEnd() | Add-Content -LiteralPath '$f'`""
}

# ---------- the machine ----------

function Get-Arch {
  $a = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment').PROCESSOR_ARCHITECTURE
  if ($a -eq 'ARM64') { 'arm64' } else { 'x64' }
}

function Update-SessionPath {
  $m = [Environment]::GetEnvironmentVariable('Path', 'Machine')
  $u = [Environment]::GetEnvironmentVariable('Path', 'User')
  $env:Path = "$u;$m"
}

# Puts a folder at the front of this user's PATH (kept as an expandable string), and tells Windows so new windows see it.
function Add-UserPath([string]$dir) {
  $k = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Environment', $true)
  $old = [string]$k.GetValue('Path', '', 'DoNotExpandEnvironmentNames')
  $parts = @($old -split ';' | Where-Object { $_ -and $_.TrimEnd('\') -ne $dir.TrimEnd('\') })
  $k.SetValue('Path', (@($dir) + $parts) -join ';', 'ExpandString')
  $k.Close()
  Set-UserVar 'GIGI_HELPER_PATH_TICK' ([string](Get-Date).Ticks)   # a user variable change makes Windows broadcast
  Update-SessionPath
}

function Set-UserVar([string]$name, [string]$value) {
  [Environment]::SetEnvironmentVariable($name, $value, 'User')
  Set-Item -Path "env:$name" -Value $value
}

# A real program on the PATH. Windows' own python3 and python in WindowsApps are Store shortcuts, not Python.
function Get-Cmd([string]$name) { Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike '*\WindowsApps\*' } | Select-Object -First 1 }
function Test-Cmd([string]$name) { [bool](Get-Cmd $name) }

function Save-Url([string]$url, [string]$file) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  $ProgressPreference = 'SilentlyContinue'
  Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $file -Headers @{ 'User-Agent' = 'GigiHelper/1.0 (Windows)' }
}

function Get-LatestAsset([string]$repo, [string]$pattern) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  if (-not $env:GIGI_NO_GH_API) {
    try {
      $r = Invoke-RestMethod -UseBasicParsing -Uri "https://api.github.com/repos/$repo/releases/latest" -Headers @{ 'User-Agent' = 'GigiHelper/1.0' }
      $a = $r.assets | Where-Object { $_.name -match $pattern } | Select-Object -First 1
      if ($a) { return $a.browser_download_url }
    } catch { }
  }
  # Without the API (60 calls an hour per network, so a classroom on one Wi-Fi runs out): the releases page.
  $q = [Net.WebRequest]::Create("https://github.com/$repo/releases/latest")
  $q.Method = 'HEAD'; $q.UserAgent = 'GigiHelper/1.0'
  $resp = $q.GetResponse(); $tag = $resp.ResponseUri.Segments[-1]; $resp.Close()
  $html = (Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/$repo/releases/expanded_assets/$tag" -Headers @{ 'User-Agent' = 'GigiHelper/1.0' }).Content
  foreach ($m in [regex]::Matches($html, 'href="(/[^"]+/releases/download/[^"]+)"')) {
    $u = $m.Groups[1].Value
    if ([IO.Path]::GetFileName($u) -match $pattern) { return "https://github.com$u" }
  }
  throw "No download matching $pattern in $repo"
}

# Runs a program and waits; throws with the end of its output when it fails.
function Invoke-Exe([string]$file, [string[]]$arguments) {
  $out = Join-Path $Dir 'last.out'
  $err = Join-Path $Dir 'last.err'
  $p = Start-Process -FilePath $file -ArgumentList $arguments -Wait -PassThru -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err
  if ($p.ExitCode -ne 0) {
    $tail = ((Get-Content $err -Raw -ErrorAction SilentlyContinue) + (Get-Content $out -Raw -ErrorAction SilentlyContinue)).Trim()
    throw "$([IO.Path]::GetFileName($file)) exited with code $($p.ExitCode). $tail"
  }
}

function Get-ClaudeExe {
  $c = Get-Command claude -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($c) { return $c.Source }
  $f = Join-Path $env:USERPROFILE '.local\bin\claude.exe'
  if (Test-Path $f) { return $f }
  $null
}

function Get-ClaudeApp { Get-AppxPackage -Name '*Claude*' -ErrorAction SilentlyContinue | Where-Object { $_.Publisher -match 'Anthropic' } | Select-Object -First 1 }

function Open-ClaudeApp {
  $app = Get-ClaudeApp
  if (-not $app) { throw 'The Claude app is not installed.' }
  $id = (Get-AppxPackageManifest $app).Package.Applications.Application.Id | Select-Object -First 1
  Start-Process "shell:AppsFolder\$($app.PackageFamilyName)!$id"
}

function Test-SetupDone {
  $c = Join-Path (Get-KitPath) 'context'
  foreach ($f in 'me.md', 'current-priorities.md') { $p = Join-Path $c $f; if (-not ((Test-Path $p) -and (Get-Item $p).Length -gt 0)) { return $false } }
  $true
}

function Test-KitInstalled {
  $ErrorActionPreference = 'Continue'
  if (-not (Test-Cmd git)) { return $false }
  $null = & git -C (Get-KitPath) remote get-url origin 2>$null
  $LASTEXITCODE -eq 0
}

function Test-Tools {
  $ErrorActionPreference = 'Continue'
  Update-SessionPath
  if (-not ((Test-Cmd git) -and (Test-Cmd gh) -and (Test-Cmd python3))) { return $false }
  $null = & (Get-Cmd python3).Source -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>$null
  $LASTEXITCODE -eq 0
}

function Test-Superpowers {
  $ErrorActionPreference = 'Continue'
  $c = Get-ClaudeExe
  if (-not $c) { return $false }
  $list = & $c plugin list 2>$null | Out-String
  ($list -match 'superpowers') -and (Test-Seeded)
}

function Test-PluginListed {
  $ErrorActionPreference = 'Continue'
  $c = Get-ClaudeExe
  if (-not $c) { return $false }
  [bool]((& $c plugin list 2>$null | Out-String) -match 'superpowers')
}

function Test-ClaudeSignedIn {
  $ErrorActionPreference = 'Continue'
  $c = Get-ClaudeExe
  if (-not $c) { return $false }
  $null = & $c auth status 2>$null
  $LASTEXITCODE -eq 0
}

function Test-GhSignedIn {
  $ErrorActionPreference = 'Continue'
  if (-not (Test-Cmd gh)) { return $false }
  $null = & gh auth status 2>$null
  $LASTEXITCODE -eq 0
}

# Claude Code's first-run questions (theme, trust this folder) answered ahead of time, so nobody types. The kit folder is
# written in both slash forms (which one Claude Code uses on Windows is checked on the test PC).
function Get-KitKeys { $k = Get-KitPath; @($k, ($k -replace '\\', '/')) }

function Read-Json([string]$file) {
  if (Test-Path $file) { try { return (Get-Content $file -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { } }
  New-Object PSObject
}
function Write-Json($obj, [string]$file) {
  $null = New-Item -ItemType Directory -Force -Path (Split-Path $file)
  [IO.File]::WriteAllText($file, ($obj | ConvertTo-Json -Depth 30), (New-Object Text.UTF8Encoding($false)))
}
function Set-Prop($obj, [string]$name, $value) {
  if ($obj.PSObject.Properties[$name]) { $obj.$name = $value } else { $obj | Add-Member -NotePropertyName $name -NotePropertyValue $value }
}

function Test-Seeded {
  $d = Read-Json (Join-Path $env:USERPROFILE '.claude.json')
  if (-not $d.hasCompletedOnboarding) { return $false }
  foreach ($k in Get-KitKeys) { if ($d.projects -and $d.projects.$k -and $d.projects.$k.hasTrustDialogAccepted) { return $true } }
  $false
}

function Invoke-SeedClaude {
  $f = Join-Path $env:USERPROFILE '.claude.json'
  $d = Read-Json $f
  Set-Prop $d 'hasCompletedOnboarding' $true
  if (-not $d.theme) { Set-Prop $d 'theme' 'light' }
  if (-not $d.projects) { Set-Prop $d 'projects' (New-Object PSObject) }
  foreach ($k in Get-KitKeys) {
    if (-not $d.projects.$k) { Set-Prop $d.projects $k (New-Object PSObject) }
    Set-Prop $d.projects.$k 'hasTrustDialogAccepted' $true
  }
  Write-Json $d $f
}

# Claude Code tells her whenever it asks for approval, so she can say what it means. Removed when setup is done.
function Set-AskHook([bool]$on) {
  $f = Join-Path $env:USERPROFILE '.claude\settings.json'
  $d = Read-Json $f
  if (-not $d.hooks) { Set-Prop $d 'hooks' (New-Object PSObject) }
  $keep = @($d.hooks.Notification | Where-Object { $_ -and (($_ | ConvertTo-Json -Depth 10) -notmatch 'claude-asks\.jsonl') })
  if ($on) { $keep += [pscustomobject]@{ matcher = 'permission_prompt'; hooks = @([pscustomobject]@{ type = 'command'; command = (Get-HookCommand) }) } }
  if ($keep.Count) { Set-Prop $d.hooks 'Notification' $keep } else { $d.hooks.PSObject.Properties.Remove('Notification') }
  if (-not @($d.hooks.PSObject.Properties).Count) { $d.PSObject.Properties.Remove('hooks') }
  Write-Json $d $f
}

# ---------- the installs ----------

function Install-Kit {
  $docs = Split-Path (Get-KitPath)
  $null = New-Item -ItemType Directory -Force -Path $docs
  $t = Join-Path $env:TEMP ('gigi-kit-' + [guid]::NewGuid())
  $null = New-Item -ItemType Directory -Path $t
  try {
    Save-Url $KitZip (Join-Path $t 'kit.zip')
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory((Join-Path $t 'kit.zip'), (Join-Path $t 'x'))
    $src = Get-ChildItem (Join-Path $t 'x') -Recurse -Filter 'CLAUDE.md' | Sort-Object { $_.FullName.Length } | Select-Object -First 1
    if (-not $src) { throw 'The kit download had no CLAUDE.md in it.' }
    $null = New-Item -ItemType Directory -Force -Path (Get-KitPath)
    Copy-Item -Path (Join-Path $src.DirectoryName '*') -Destination (Get-KitPath) -Recurse -Force
  } finally { Remove-Item $t -Recurse -Force -ErrorAction SilentlyContinue }
}

function Install-ClaudeApp {
  $f = Join-Path $env:TEMP 'Claude.msix'
  Save-Url "https://claude.ai/api/desktop/win32/$(Get-Arch)/msix/latest/redirect" $f
  Add-AppxPackage -Path $f
  Remove-Item $f -Force -ErrorAction SilentlyContinue
}

function Install-Git {
  $want = if ((Get-Arch) -eq 'arm64') { 'PortableGit-.*-arm64\.7z\.exe$' } else { 'PortableGit-.*-64-bit\.7z\.exe$' }
  $exe = Join-Path $env:TEMP 'PortableGit.7z.exe'
  Save-Url (Get-LatestAsset 'git-for-windows/git' $want) $exe
  $to = Join-Path $Programs 'Git'
  Invoke-Exe $exe @('-y', "-o`"$to`"")
  Remove-Item $exe -Force -ErrorAction SilentlyContinue
  $post = Join-Path $to 'post-install.bat'
  if (Test-Path $post) { Push-Location $to; try { $ErrorActionPreference = 'Continue'; $null = & cmd.exe /c 'post-install.bat' 2>$null } finally { Pop-Location } }
  Add-UserPath (Join-Path $to 'cmd')
  Set-UserVar 'CLAUDE_CODE_GIT_BASH_PATH' (Join-Path $to 'bin\bash.exe')
}

function Install-Python {
  $a = if ((Get-Arch) -eq 'arm64') { 'arm64' } else { 'amd64' }
  $exe = Join-Path $env:TEMP "python-$PythonVersion-$a.exe"
  Save-Url "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-$a.exe" $exe
  Invoke-Exe $exe @('/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_test=0', 'Include_launcher=0', 'Shortcuts=0')
  Remove-Item $exe -Force -ErrorAction SilentlyContinue
  Update-SessionPath
  # The kit's scripts call python3; Windows' own python3 is a Store shortcut. A copy of the real one wins on the PATH.
  $py = Join-Path $Programs ('Python\Python' + ($PythonVersion -replace '^(\d+)\.(\d+).*$', '$1$2'))
  if (Test-Path (Join-Path $py 'python.exe')) { Copy-Item (Join-Path $py 'python.exe') (Join-Path $py 'python3.exe') -Force }
}

function Install-Gh {
  $want = if ((Get-Arch) -eq 'arm64') { 'windows_arm64\.zip$' } else { 'windows_amd64\.zip$' }
  $zip = Join-Path $env:TEMP 'gh.zip'
  Save-Url (Get-LatestAsset 'cli/cli' $want) $zip
  $to = Join-Path $Programs 'gh'
  Remove-Item $to -Recurse -Force -ErrorAction SilentlyContinue
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $to)
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
  Add-UserPath (Join-Path $to 'bin')
}

function Install-Tools {
  Update-SessionPath
  if (-not (Test-Cmd git)) { Install-Git }
  if (-not (Test-Cmd python3)) { Install-Python }
  if (-not (Test-Cmd gh)) { Install-Gh }
}

function Install-ClaudeCode { Invoke-Exe 'powershell.exe' @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', 'irm https://claude.ai/install.ps1 | iex'); Add-UserPath (Join-Path $env:USERPROFILE '.local\bin') }

function Install-Superpowers {
  $c = Get-ClaudeExe
  try { Invoke-Exe $c @('plugin', 'marketplace', 'add', 'anthropics/claude-plugins-official') } catch { }
  Invoke-Exe $c @('plugin', 'install', 'superpowers@claude-plugins-official')
}

# What a console step runs: the kit install with Claude, with the install prompt from prompts.json.
function Get-InstallCommand {
  $tools = @("'Bash(git:*)'", "'Bash(gh:*)'", "'Bash(ls:*)'", "'Bash(uname:*)'", "'Bash(python3:*)'", "'Bash(python:*)'", "'Bash(claude plugin:*)'", "'Bash(cp:*)'", "'Bash(chmod:*)'", "'Bash(mkdir:*)'", "'Bash(cat:*)'", 'Read', 'Write', 'Edit') -join ' '
  @"
Set-Location -LiteralPath '$((Get-KitPath) -replace "'", "''")'
`$p = "I am on Windows, not Mac. Give me Windows install steps. Use Git Bash commands.``n``n" + (Get-Content -Raw -Encoding UTF8 -LiteralPath '$((Join-Path $Dir 'install_prompt.txt') -replace "'", "''")')
`$p = `$p -replace '(\\*)"', '`$1`$1\"'
& '$((Get-ClaudeExe) -replace "'", "''")' --allowedTools $tools -- `$p
"@
}

# ---------- the steps ----------

function Get-GigiSteps([bool]$Interview) {
  $list = @(
    @{ id = 'before_you_start'; title = 'Before you start'; check = $null; phases = @(
        @{ kind = 'ask'; say = $Say.plan; yes = 'I have both'; help = 'I need a GitHub account'; url = 'https://github.com/join' }) }
    @{ id = 'download_kit'; title = 'Download the kit'; check = { Test-Path (Join-Path (Get-KitPath) 'CLAUDE.md') }; phases = @(
        @{ kind = 'run'; run = { Install-Kit }; skipIf = $null }) }
    @{ id = 'install_claude_app'; title = 'Install the Claude app'; check = $null; phases = @(
        @{ kind = 'run'; run = { Install-ClaudeApp }; skipIf = { [bool](Get-ClaudeApp) } }
        @{ kind = 'run'; run = { Open-ClaudeApp }; skipIf = $null }
        @{ kind = 'ask'; say = $Say.claudeApp; yes = "I'm signed in"; help = $null; url = $null }) }
    @{ id = 'tools'; title = 'Install Git and Python'; check = { Test-Tools }; phases = @(
        @{ kind = 'status'; text = $Say.toolsStatus; unless = { Test-Tools } }
        @{ kind = 'run'; run = { Install-Tools }; skipIf = { Test-Tools } }) }
    @{ id = 'superpowers_plugin'; title = 'Add Superpowers'; check = { Test-Superpowers }; phases = @(
        @{ kind = 'run'; run = { Install-ClaudeCode }; skipIf = { [bool](Get-ClaudeExe) } }
        @{ kind = 'run'; run = { Install-Superpowers }; skipIf = { Test-PluginListed } }
        @{ kind = 'run'; run = { Invoke-SeedClaude }; skipIf = { Test-Seeded } }
        @{ kind = 'run'; run = { Set-AskHook $true }; skipIf = $null }) }
    @{ id = 'kit_install_prompt'; title = 'Run the kit install'; check = { Test-KitInstalled }; phases = @(
        @{ kind = 'console'; cmd = { "& '$((Get-ClaudeExe) -replace "'", "''")' auth login --claudeai" }; until = { Test-ClaudeSignedIn }; say = $Say.claudeSignIn }
        @{ kind = 'device'; until = { Test-GhSignedIn }; say = $Say.gitHubSignIn; url = $GitHubDevice }
        @{ kind = 'console'; cmd = { Get-InstallCommand }; until = { Test-KitInstalled }; say = $Say.install }) }
    @{ id = 'setup_interview'; title = 'The setup interview'; check = { Test-SetupDone }; phases = @(
        @{ kind = 'run'; run = { Start-Process (Get-CodeLink '/setup') }; skipIf = { Test-SetupDone } }
        @{ kind = 'wait'; until = { Test-SetupDone }; say = $Say.interview }) }
    @{ id = 'see_it_work'; title = 'See it work'; check = $null; phases = @(
        @{ kind = 'run'; run = { Start-Process (Get-CodeLink (Get-Content -Raw -Encoding UTF8 (Join-Path $Dir 'first_prompt.txt'))) }; skipIf = $null }
        @{ kind = 'ask'; say = $Say.firstPrompt; yes = 'Yes, it did'; help = $null; url = $null }
        @{ kind = 'run'; run = { Set-AskHook $false }; skipIf = $null }) }
  )
  if ($Interview) { return $list }
  # A Bootcamp seat (Max, 2026-11-12): she stops once the kit is installed; the interview happens at the bootcamp.
  @($list | Where-Object { $_.id -ne 'setup_interview' -and $_.id -ne 'see_it_work' }) + @(
    @{ id = 'all_set'; title = 'Ready for the bootcamp'; check = $null; phases = @(@{ kind = 'run'; run = { Set-AskHook $false }; skipIf = $null }) })
}

# The script a console step opens: her line on top, the command, then a goodbye. It moves its own window to the right of
# her card (440 wide at the left edge).
function Get-ConsoleScript([string]$cmd, [string]$say) {
  $q = $say -replace "'", "''"
  @"
`$Host.UI.RawUI.WindowTitle = 'Gigi Helper'
try {
  Add-Type -Namespace Gigi -Name Win -MemberDefinition '[DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool SetWindowPos(System.IntPtr h, System.IntPtr a, int x, int y, int cx, int cy, uint f);'
  [void][Gigi.Win]::SetWindowPos([Gigi.Win]::GetConsoleWindow(), [IntPtr]::Zero, 470, 40, 900, 640, 0x0040)
} catch { }
Update-SessionPath
Clear-Host
Write-Host ''
Write-Host '  Gigi: $q' -ForegroundColor Yellow
Write-Host ''
$cmd
Write-Host ''
Write-Host '  Gigi: this part is done. This window closes by itself. My card shows what happens next.' -ForegroundColor Yellow
Start-Sleep -Seconds 8
"@
}

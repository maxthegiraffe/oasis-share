# The runner's plumbing that the self-test checks (final review, 2026-11-13): the request reader, when her card comes
# back, this PC's id, and writing down a crash. Dot-sourced by gigi.ps1 after steps.ps1.

# One HTTP request from the card, read as bytes (a pasted code can hold an en dash or a no-break space). $null when the
# connection sends nothing (Edge opens spare connections it may never use).
function Read-HttpRequest([IO.Stream]$s) {
  $head = New-Object IO.MemoryStream
  $one = New-Object byte[] 1
  $tail = 0
  while ($head.Length -lt 16384) {
    $n = 0
    try { $n = $s.Read($one, 0, 1) } catch { $n = 0 }
    if ($n -le 0) { break }
    $head.WriteByte($one[0])
    $tail = (($tail -shl 8) -bor $one[0]) -band 0xFFFFFFFF
    if ($tail -eq 0x0D0A0D0A) { break }
  }
  if ($head.Length -eq 0 -or $tail -ne 0x0D0A0D0A) { return $null }
  $lines = [Text.Encoding]::ASCII.GetString($head.ToArray()) -split "`r`n"
  $parts = $lines[0].Split(' ')
  if ($parts.Count -lt 2) { return $null }
  $h = @{}
  foreach ($l in $lines[1..($lines.Count - 1)]) { $i = $l.IndexOf(':'); if ($i -gt 0) { $h[$l.Substring(0, $i).Trim().ToLowerInvariant()] = $l.Substring($i + 1).Trim() } }
  $body = ''
  $len = 0
  if ($h['content-length'] -and [int]::TryParse($h['content-length'], [ref]$len) -and $len -gt 0 -and $len -le 65536) {
    $buf = New-Object byte[] $len
    $got = 0
    while ($got -lt $len) { $n = $s.Read($buf, $got, $len - $got); if ($n -le 0) { break }; $got += $n }
    $body = [Text.Encoding]::UTF8.GetString($buf, 0, $got)
  }
  $q = $parts[1].IndexOf('?')
  @{ method = $parts[0]; target = $parts[1]; path = $(if ($q -ge 0) { $parts[1].Substring(0, $q) } else { $parts[1] }); headers = $h; body = $body }
}

# Her card closed without Quit comes back, but only with Edge (no endless browser tabs) and at most 3 times in a row.
function Test-ShouldReopen([double]$seenAgo, [double]$openedAgo, [int]$reopens, [bool]$hasEdge) {
  $hasEdge -and $reopens -lt 3 -and $seenAgo -gt 10 -and $openedAgo -gt 20
}

# This PC's id for her code, kept in the registry: Quit tidies her folder away, and the code must still work here after.
function Get-DeviceId {
  if ($env:GIGI_DEVICE) { return $env:GIGI_DEVICE }   # tests only: the same id each run
  $k = 'HKCU:\Software\Grateful Giraffes\Gigi Helper'
  $id = $null
  try { $id = (Get-ItemProperty -Path $k -ErrorAction Stop).Device } catch { }
  if (-not $id) {
    $id = [guid]::NewGuid().ToString()
    $null = New-Item -Path $k -Force
    $null = New-ItemProperty -Path $k -Name Device -Value $id -PropertyType String -Force
  }
  $id
}

# A crash is written down, and (unless it's a test) she says so in a box, since her window may never have opened.
function Show-Fatal([string]$what, [switch]$NoBox) {
  try { [IO.File]::AppendAllText((Join-Path $Dir 'gigi.log'), "$(Get-Date -Format s) fatal: $what`r`n") } catch { }
  if ($NoBox) { return }
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [void][Windows.Forms.MessageBox]::Show("Gigi Helper stopped before she could finish. Text Gigi at (516) 419-7249 and she'll sort it out.`n`n$what", 'Gigi Helper')
  } catch { }
}

# The step loop (the Mac's Sources/Runner.swift), run in a background runspace by gigi.ps1. It shares $S (a synchronized
# hashtable) with the card's server: it only ever writes the step fields, the line and the notes. $AppDir is set by gigi.ps1.
$ErrorActionPreference = 'Stop'
. (Join-Path $AppDir 'lines.ps1')
. (Join-Path $AppDir 'steps.ps1')
. (Join-Path $AppDir 'core.ps1')

function Write-Log([string]$t) {
  [Threading.Monitor]::Enter($S.SyncRoot)
  try { [IO.File]::AppendAllText((Join-Path $Dir 'gigi.log'), "$(Get-Date -Format s) runner: $t`r`n") } catch { } finally { [Threading.Monitor]::Exit($S.SyncRoot) }
}

function Add-Note([string]$t) {
  [Threading.Monitor]::Enter($S.SyncRoot)
  try {
    $S.seq = $S.seq + 1
    $null = $S.notes.Add(@{ seq = $S.seq; text = $t; speak = (-not $t.Contains('was already done')) })
    while ($S.notes.Count -gt 60) { $S.notes.RemoveAt(0) }
    $S.lastNote = $t
  } finally { [Threading.Monitor]::Exit($S.SyncRoot) }
  Write-Log $t.Substring(0, [Math]::Min(240, $t.Length))
}

function Test-Block($b) { if (-not $b) { return $false }; try { [bool](& $b) } catch { $false } }
function Test-Going { $S.stage -eq 'running' -and -not $S.quit }

function Set-StepState([int]$i, [string]$st, [string]$detail = '') {
  $S.steps[$i].state = $st; $S.stepsVersion = $S.stepsVersion + 1
  # Every step change goes to Gigi's cloud, and the PC's details again once the Claude app is in (Max, 11-13).
  $secs = [int]((Get-Date) - $S.stepStart).TotalSeconds
  Send-Report $S.home $S.pass (New-StepEvent $S.steps[$i].id $S.steps[$i].title $st ($i + 1) $S.steps.Count $secs $detail)
  if ($st -eq 'done' -and $S.steps[$i].id -eq 'install_claude_app') { Send-Report $S.home $S.pass (New-EnvEvent) }
}

function Clear-Hand {
  $S.waiting = $false; $S.handoff = $null; $S.second = $null; $S.deviceCode = $null; $S.inBrowser = $false
  $S.side = 'left'; $S.doing = $null; $S.asking = $false; $S.consolePid = 0; $S.showApp = $false
}

function Complete-Step($steps, [int]$i, [bool]$skipped) {
  Set-StepState $i 'done'
  Clear-Hand
  if ($skipped) { Add-Note "HANDS: Step $($i + 1), $($steps[$i].title), was already done on this PC, so I skipped it." }
  else { Add-Note "HANDS: Step $($i + 1) is done: $($steps[$i].title)." }
  $true
}

function Stop-Step($steps, [int]$i, [string]$detail) {
  Set-StepState $i 'failed' $detail
  Clear-Hand
  $S.line = Get-FailLine $steps[$i].title $detail
  $S.stage = 'failed'
  $tail = ([string]$detail).Trim()
  if ($tail.Length -gt 300) { $tail = $tail.Substring($tail.Length - 300) }
  Add-Note "HANDS error: Step $($i + 1), $($steps[$i].title), didn't finish: $tail"
  $false
}

function Wait-Until($until, [scriptblock]$alsoFail) {
  while (Test-Going) {
    Start-Sleep -Seconds 2
    if (Test-Block $until) { return 'ok' }
    if ($alsoFail) { $why = & $alsoFail; if ($why) { return $why } }
  }
  'stopped'
}

function Open-Console([string]$id, [int]$n, [string]$cmd, [string]$say) {
  $f = Join-Path $Dir "$id-$n.ps1"
  $text = ". '$((Join-Path $AppDir 'steps.ps1') -replace "'", "''")'`r`n" + (Get-ConsoleScript $cmd $say)
  [IO.File]::WriteAllText($f, $text, (New-Object Text.UTF8Encoding($true)))
  $line = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$f`""
  # conhost keeps it a classic window we can place beside her card (Windows Terminal ignores placement).
  try { return Start-Process -FilePath 'conhost.exe' -ArgumentList $line -PassThru }
  catch { return Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$f`"") -PassThru }
}

function Invoke-Step($steps, [int]$i) {
  $step = $steps[$i]   # never $s: PowerShell names ignore case, and $S is the shared state
  $asks = @($step.phases | Where-Object { $_.kind -eq 'ask' }).Count -gt 0
  $confirmed = @($S.confirmed) -contains $step.id
  if ($step.check -and (Test-Block $step.check) -and (-not $asks -or $confirmed)) { return Complete-Step $steps $i $true }
  if (-not $step.check -and $asks -and $confirmed) { return Complete-Step $steps $i $true }
  Clear-Hand
  Set-StepState $i 'running'
  $S.stepStart = Get-Date
  $S.line = @{ say = "Working on: $($step.title)."; button = 'Stop'; do = 'stop' }
  Add-Note "HANDS: Starting step $($i + 1) of $($steps.Count): $($step.title)."
  for ($n = 0; $n -lt $step.phases.Count; $n++) {
    if (-not (Test-Going)) { return $false }
    $p = $step.phases[$n]
    switch ($p.kind) {
      'run' {
        if (Test-Block $p.skipIf) { continue }
        try { $null = & $p.run } catch { return Stop-Step $steps $i $_.Exception.Message }
      }
      'status' {
        if (Test-Block $p.unless) { continue }
        $S.doing = $p.text
        Add-Note "HANDS: $($p.text)"
      }
      'console' {
        if (Test-Block $p.until) { continue }
        try { $proc = Open-Console $step.id $n ([string](& $p.cmd)) $p.say } catch { return Stop-Step $steps $i "Couldn't open PowerShell: $($_.Exception.Message)" }
        $S.consolePid = $proc.Id
        Set-StepState $i 'waiting'
        $S.waiting = $true; $S.handoff = $p.say; $S.line = @{ say = $p.say; button = 'Stop'; do = 'stop' }
        $S.second = @{ text = 'Show me the window'; do = 'show' }
        if ($p.say -eq $Say.claudeSignIn) { $S.inBrowser = $true; $S.side = 'right' }
        Add-Note "HANDS need_person: $($p.say)"
        $script:seen = $false; $script:quiet = 0
        $r = Wait-Until $p.until {
          $running = -not $proc.HasExited
          if ($running) { $script:seen = $true; $script:quiet = 0 } else { $script:quiet++ }
          if (($script:seen -and -not $running) -or $script:quiet -gt 30) { 'ended' }
        }
        if ($r -eq 'stopped') { return $false }
        if ($r -eq 'ended') { return Stop-Step $steps $i $Say.endedEarly }
        Clear-Hand
        Set-StepState $i 'running'
        $S.line = @{ say = "Working on: $($step.title)."; button = 'Stop'; do = 'stop' }
        $next = if ($n + 1 -lt $step.phases.Count) { $step.phases[$n + 1].kind } else { '' }
        if ($next -ne 'status') { Add-Note "HANDS: Their part of $($step.title) is done. I'm carrying on by myself now, nothing needed from them." }
      }
      'ask' {
        $S.answer = $false
        $S.asking = $true
        $S.askUrl = $p.url
        Set-StepState $i 'waiting'
        $S.line = @{ say = $p.say; button = $p.yes; do = 'confirm' }
        if ($p.help) { $S.second = @{ text = $p.help; do = 'help' } } else { $S.second = $null }
        Add-Note "HANDS need_person: Ask them: $($p.say) When they say yes, call step_confirmed."
        while ((Test-Going) -and -not $S.answer) { Start-Sleep -Milliseconds 300 }
        if (-not $S.answer) { return $false }
        $S.confirmed = @($S.confirmed) + $step.id
        $S.saveNeeded = $true
        Clear-Hand
        Set-StepState $i 'running'
        $S.line = @{ say = "Working on: $($step.title)."; button = 'Stop'; do = 'stop' }
      }
      'wait' {
        if (Test-Block $p.until) { continue }
        Set-StepState $i 'waiting'
        $S.waiting = $true; $S.handoff = $p.say; $S.showApp = $true
        $S.line = @{ say = $p.say; button = 'Stop'; do = 'stop' }
        $S.second = @{ text = 'Show me the window'; do = 'show' }
        Add-Note "HANDS need_person: $($p.say)"
        if ((Wait-Until $p.until $null) -ne 'ok') { return $false }
        Clear-Hand
        Set-StepState $i 'running'
      }
      'device' {
        if (Test-Block $p.until) { continue }
        Get-Process gh -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        $out = Join-Path $Dir "$($step.id).out"; $err = Join-Path $Dir "$($step.id).err"; $nl = Join-Path $Dir 'enter.txt'
        [IO.File]::WriteAllText($nl, "`r`n")
        Remove-Item $out, $err -ErrorAction SilentlyContinue
        $env:GH_BROWSER = 'cmd /c exit'   # she opens the page herself, once
        try {
          $gh = Start-Process -FilePath 'gh' -ArgumentList @('auth', 'login', '--hostname', 'github.com', '--git-protocol', 'https', '--web', '--clipboard') `
            -RedirectStandardInput $nl -RedirectStandardOutput $out -RedirectStandardError $err -WindowStyle Hidden -PassThru
        } catch { return Stop-Step $steps $i "Couldn't start GitHub's sign in: $($_.Exception.Message)" }
        $code = $null
        for ($k = 0; $k -lt 40 -and -not $code; $k++) {
          if (-not (Test-Going)) { return $false }
          Start-Sleep -Milliseconds 500
          $code = Get-DeviceCode (((Get-Content $err -Raw -ErrorAction SilentlyContinue) + (Get-Content $out -Raw -ErrorAction SilentlyContinue)))
        }
        if (-not $code) { return Stop-Step $steps $i ("The sign in didn't give me a code. " + (Get-Content $err -Raw -ErrorAction SilentlyContinue)) }
        Set-StepState $i 'waiting'
        $S.waiting = $true; $S.handoff = $p.say; $S.deviceCode = $code; $S.inBrowser = $true; $S.side = 'right'
        $S.line = @{ say = $p.say; button = 'Stop'; do = 'stop' }
        Start-Process $p.url
        Add-Note "HANDS need_person: $($p.say)"
        $r = Wait-Until $p.until { if ($gh.HasExited -and -not (Test-GhSignedIn)) { 'expired' } }
        if ($r -eq 'stopped') { return $false }
        if ($r -eq 'expired') { return Stop-Step $steps $i $Say.codeExpired }
        Clear-Hand
        Set-StepState $i 'running'
      }
    }
  }
  if ($step.check -and -not (Test-Block $step.check)) { return Stop-Step $steps $i "The check for $($step.title) still doesn't pass." }
  Complete-Step $steps $i $false
}

function Invoke-Steps {
  $steps = Get-GigiSteps $S.interview
  if (-not $S.envSent) { $S.envSent = $true; Send-Report $S.home $S.pass (New-EnvEvent) }
  for ($i = $S.at; $i -lt $steps.Count; $i++) {
    if (-not (Test-Going)) { return }
    $S.at = $i
    if (-not (Invoke-Step $steps $i)) { return }
  }
  $S.at = $steps.Count
  Clear-Hand
  if ($S.interview) { $S.line = $Lines.done } else { $S.line = $Lines.doneBootcamp }
  $S.stage = 'done'
  Send-Report $S.home $S.pass @{ kind = 'finished'; of = $steps.Count }
  Add-Note (Get-FinishedNote $steps.Count $S.interview)
}

Write-Log 'runner up'
while (-not $S.quit) {
  if ($S.stage -eq 'running') {
    try { Invoke-Steps } catch { Write-Log "loop: $($_.Exception.Message)"; $S.stage = 'failed'; $S.line = Get-FailLine 'Setup' $_.Exception.Message }
  }
  Start-Sleep -Milliseconds 300
}

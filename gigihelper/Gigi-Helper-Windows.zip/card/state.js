// The card's pure parts (Gigi Helper for Windows, 2026-11-12). The runner (gigi.ps1) owns the state; the card shows it,
// speaks its notes once each, and answers her voice tools the way the Mac app does (Sources/main.swift, Core.swift).

/** The notes after lastSeq, and the new lastSeq. Each note is spoken (or given as context) exactly once. */
export function newNotes(notes, lastSeq) {
  const fresh = (notes || []).filter((n) => n.seq > lastSeq);
  const top = fresh.reduce((m, n) => Math.max(m, n.seq), lastSeq);
  return { fresh, lastSeq: top };
}

/** What her voice tool calls answer, from the runner's state (the same words as the Mac's voice.onTool). */
export function toolResult(name, state) {
  if (name === "stop_hands") return "stopped";
  if (name === "resume_hands") return "resumed";
  if (name === "step_confirmed") return state.asking ? "confirmed, carrying on" : "nothing to confirm right now";
  const steps = state.steps || [];
  const at = Math.max(0, Math.min(state.at || 0, steps.length - 1));
  return `Step ${at + 1} of ${steps.length}: ${steps[at]?.title || ""}. Last note: ${state.lastNote || ""}`;
}

export const BOT_BLOCK_TIP = "Page says access is restricted? Press Control and R to refresh it.";

/** The small line under her steps once a step has run a while, so a long quiet install never looks stuck. */
export function stillWorking(seconds, waiting, doing, inBrowser) {
  const mins = Math.floor(seconds / 60);
  if (!waiting && doing) return seconds >= 60 ? `${doing} ${mins} min so far.` : doing;
  if (waiting && inBrowser) return (seconds >= 60 ? `Waiting for you: ${mins} min. ` : "") + BOT_BLOCK_TIP;
  if (seconds < 60) return null;
  return waiting ? `Waiting for you: ${mins} min. Can't find the window? Click Show me the window.`
    : `Still working: ${mins} min so far on this step. Nothing for you to do.`;
}

/** The mic was refused: she carries on, her words stay on the card. */
export function micDenied(state) {
  return { ...state, wordsOnly: true };
}

export const BOT_BLOCK_NOTE = "If the page says access is restricted, or asks if they're human, the site has mistaken them for a bot. Tell them that's normal: press Control and R to refresh, then try again.";

/** She checks in on a long step only when it's been quiet a while, and not too often (the Mac's Flow.shouldCheckIn). */
export const shouldCheckIn = (stepSeconds, quietSeconds, sinceCheckIn) => stepSeconds >= 45 && quietSeconds >= 25 && sinceCheckIn >= 75;

/** Reminders of what they still need to do space out: 2 minutes, then 4, then 8, then every 10. */
export const reminderGap = (sent) => Math.min(600, 120 << Math.min(sent, 3));

/** What she's told when she checks in: a reminder while she waits on them, or her time to get to know them. */
export function checkInNote(title, seconds, waitingOn, inBrowser) {
  const mins = Math.floor(seconds / 60);
  if (waitingOn) {
    const tip = inBrowser ? ` ${BOT_BLOCK_NOTE}` : "";
    return `HANDS need_person reminder: Still waiting on them for ${title}, ${mins} minutes so far.${tip} What they need to do: ${waitingOn} Gently ask if they found it, and offer to help. The button Show me the window brings it back.`;
  }
  return `HANDS wait: Still on ${title}, ${mins} minutes so far, and that's normal. Nothing is needed from them right now. Use this time to get to know them: ask one warm question, or follow up on what they just told you.`;
}

/** A call that ran its full hour with nobody speaking doesn't reopen by itself (11-13); her next note opens it again. */
export const shouldReconnect = (sessionSecs, heardDuring) => heardDuring || sessionSecs < 3300;

// Her card: polls the runner (gigi.ps1) twice a second, shows what it says, speaks its notes once each, and sends the
// buttons back. The runner decides every word and every step; nothing here runs anything on the PC.
import { newNotes, toolResult, stillWorking, micDenied, shouldCheckIn, reminderGap, checkInNote } from "./state.js";
import { attachEye, EYE_CSS } from "./telepathy.js";
import { startVoice, askMic } from "./voice.js";

const KEY = new URL(location.href).searchParams.get("k") || "";
const $ = (id) => document.getElementById(id);
const api = (path, body) => fetch(path, {
  method: body ? "POST" : "GET",
  headers: { "X-Gigi-Key": KEY, ...(body ? { "content-type": "application/json" } : {}) },
  body: body ? JSON.stringify(body) : undefined,
}).then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))));
const act = (d, extra = {}) => api("/act", { do: d, ...extra }).catch(() => {});

let state = { stage: "welcome", steps: [], notes: [] };
let lastSeq = 0;
let voice = null;
let voiceStarting = false;
let micAsked = false;
let lastWords = "";
let voiceTries = 0;
let lastSpoke = Date.now();
let lastHeard = 0;
let lastCheckIn = Date.now();
let remindersSent = 0;
let lastAt = -1;

const style = document.createElement("style");
style.textContent = EYE_CSS;
document.head.append(style);
attachEye($("eye"), $("loop"));

function render(s) {
  $("say").textContent = s.line?.say || "";
  $("codebox").hidden = s.stage !== "code";
  $("devcode").hidden = !s.deviceCode;
  $("devtext").textContent = s.deviceCode || "";
  const list = $("steps");
  list.hidden = !(s.steps || []).length || !["running", "paused", "failed", "done"].includes(s.stage);
  list.replaceChildren(...(s.steps || []).map((st) => {
    const li = document.createElement("li");
    li.textContent = st.title;
    li.className = st.state === "done" ? "done" : st.state === "failed" ? "failed" : (st.state === "running" || st.state === "waiting") ? "now" : "";
    return li;
  }));
  const tip = stillWorking(s.secs || 0, !!s.waiting, s.doing || null, !!s.inBrowser);
  $("note").textContent = s.line?.note || tip || (s.wordsOnly ? lastWords : "") || "";
  const main = $("main");
  main.hidden = !s.line?.button;
  main.textContent = s.line?.button || "";
  const second = $("second");
  second.hidden = !s.second;
  second.textContent = s.second?.text || "";
}

async function poll() {
  try {
    const s = await api(`/state?since=${lastSeq}`);
    const { fresh, lastSeq: top } = newNotes(s.notes, lastSeq);
    lastSeq = top;
    state = s.micOk === false ? micDenied(s) : s;
    render(state);
    for (const n of fresh) {
      if (!voice) continue;
      try { n.speak ? voice.speak(n.text) : voice.note(n.text); } catch (e) { console.warn("note", e); }
    }
    checkIn(state);
    after(s);   // never holds up the polling (the mic box can wait on them)
  } catch (e) {
    console.warn("poll", e);
  }
  setTimeout(poll, 500);
}

// A long step never goes quiet: a reminder while she waits on them (spaced out), else a getting-to-know-you question.
function checkIn(s) {
  const now = Date.now();
  if (s.at !== lastAt) { lastAt = s.at; lastCheckIn = now; remindersSent = 0; }
  if (!voice || s.stage !== "running" || s.asking) return;
  const quiet = (now - Math.max(lastSpoke, lastHeard)) / 1000;
  const since = (now - lastCheckIn) / 1000;
  if (!shouldCheckIn(s.secs || 0, quiet, since) || (s.handoff && since < reminderGap(remindersSent))) return;
  lastCheckIn = now;
  if (s.handoff) remindersSent += 1;
  const title = (s.steps || [])[s.at]?.title || "";
  try { voice.speak(checkInNote(title, s.secs || 0, s.handoff || null, !!s.inBrowser)); } catch (e) { console.warn("check-in", e); }
}

// The stages that move by themselves: the mic box after her heads-up, then her voice once they've answered it.
async function after(s) {
  if (s.stage === "mic" && !micAsked) {
    micAsked = true;
    await new Promise((r) => setTimeout(r, 1500));
    const ok = await askMic();
    await act("mic", { ok });
  }
  if (["running", "paused"].includes(s.stage) && s.micOk && !voice && !voiceStarting) {
    voiceStarting = true;
    try {
      const link = await api("/voice");
      voice = await startVoice({
        link,
        firstLine: s.firstLine || "I'm back.",
        name: s.name,
        tools: {
          stop_hands: () => { act("stop"); return toolResult("stop_hands", state); },
          resume_hands: () => { act("resume"); return toolResult("resume_hands", state); },
          step_confirmed: () => { const r = toolResult("step_confirmed", state); if (state.asking) act("confirm"); return r; },
          where_are_we: () => toolResult("where_are_we", state),
        },
        onHeard: () => { lastHeard = Date.now(); },
        onText: (t) => { lastWords = t; lastSpoke = Date.now(); if (!state.line?.note) $("note").textContent = t; },
        onEnd: () => {
          voice = null;
          // A dropped line comes back (sleep, Wi-Fi), never more than 30 s apart; her words stay on the card.
          voiceTries += 1;
          setTimeout(() => { voiceStarting = false; }, Math.min(30000, 2000 * voiceTries));
        },
      });
      act("voice", { on: true });
      voiceTries = 0;
      voiceStarting = false;
    } catch (e) {
      console.warn("voice start", e);
      voiceTries += 1;
      setTimeout(() => { voiceStarting = false; }, Math.min(30000, 2000 * voiceTries));
    }
  }
}

$("main").addEventListener("click", () => {
  const d = state.line?.do;
  if (!d) return;
  if (d === "unlock") return act("unlock", { code: $("code").value });
  act(d);
});
$("second").addEventListener("click", () => { if (state.second?.do) act(state.second.do); });
$("codebox").addEventListener("submit", (e) => { e.preventDefault(); act("unlock", { code: $("code").value }); });
$("copy").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(state.deviceCode || ""); $("copy").textContent = "Copied"; } catch { /* select it by hand */ }
  setTimeout(() => { $("copy").textContent = "Copy my code"; }, 2000);
});

poll();

// Her live voice on Windows: the "Gigi Helper Windows" ElevenLabs agent through the web SDK (bundled as elevenlabs.js,
// global ElevenLabsClient). The browser's own echo cancellation keeps her voice from the speakers out of the mic.
import { voice as glow, say as tint, hush } from "./telepathy.js";

/**
 * Starts her voice. link: {signed_url} from the runner's /voice. tools: {name: () => string} for her four client tools.
 * onText(words) for each thing she says, onEnd() when the line drops. Returns {note(text), speak(text), end()} or throws.
 */
export async function startVoice({ link, firstLine, name, tools, onText, onHeard = () => {}, onEnd }) {
  const { Conversation } = window.ElevenLabsClient;
  const clientTools = {};
  for (const [k, fn] of Object.entries(tools)) clientTools[k] = async () => fn();
  const conv = await Conversation.startSession({
    signedUrl: link.signed_url,
    connectionType: "websocket",
    dynamicVariables: { first_line: firstLine, name: name || "" },
    clientTools,
    onMessage: ({ message, source }) => {
      if (source === "user") return onHeard();
      if (source !== "ai" || !message) return;
      tint(message);
      onText(message);
    },
    onDisconnect: () => { glow(null); hush(); onEnd(); },
    onError: (e) => console.warn("voice", e),
  });
  glow(() => conv.getOutputVolume());
  return {
    note: (t) => conv.sendContextualUpdate(t),
    speak: (t) => conv.sendUserMessage(t),
    end: () => conv.endSession(),
  };
}

/** Edge's microphone box. true = Allow. The tracks stop at once; the SDK opens its own. */
export async function askMic() {
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true });
    s.getTracks().forEach((t) => t.stop());
    return true;
  } catch {
    return false;
  }
}

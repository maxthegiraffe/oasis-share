# Her words on Windows: the Mac's Lines (Sources/Core.swift) with "PC" for "Mac", "PowerShell window" for "Terminal" and
# "click" for "tap". No dashes, no prices. Each line: say (big), button + do (the main button), note (small).

$Telepathic = "My lips aren't quite modeled yet, so for now I'm speaking to you telepathically."

$Lines = @{
  code      = @{ say = "Hi, I'm Gigi. Paste the code from my email, and I'll take it from there."; button = 'Unlock'; do = 'unlock'; note = 'It looks like GIGI-XXXX-XXXX.' }
  unlocking = @{ say = 'Checking your code.' }
  mic       = @{ say = "I'd love to hear you as we go. A box will ask about the microphone: click Allow."; note = "Rather not? Click Block, and I'll show my words here instead." }
  running   = @{ say = "I'm setting up your PC now. I'll tell you whenever I need you."; button = 'Stop'; do = 'stop' }
  paused    = @{ say = 'Stopped. Nothing runs until you say so.'; button = 'Let Gigi continue'; do = 'resume' }
  done      = @{ say = "All done. Your Agent OS is set up. Click Quit, and I'll tidy myself away."; button = 'Quit'; do = 'quit' }
  doneBootcamp = @{ say = "All done. Your PC is ready for the bootcamp, where we'll install your Agent OS kit and do the business interview together. Click Quit, and I'll tidy myself away."; button = 'Quit'; do = 'quit' }
}

function Get-RedeemLine([string]$why) {
  switch ($why) {
    'other_mac' { return @{ say = "That code is already in use on another computer. Reply to my email and I'll send you a new one."; button = 'Unlock'; do = 'unlock' } }
    'on_hold'   { return @{ say = "That code isn't ready yet. Reply to my email and I'll sort it out."; button = 'Unlock'; do = 'unlock' } }
    'expired'   { return @{ say = "Let's unlock me again. Paste the code from my email: it still works on this PC."; button = 'Unlock'; do = 'unlock' } }
    'offline'   { return @{ say = "I can't reach home right now. Check your internet, then click Try again."; button = 'Try again'; do = 'unlock' } }
    default     { return @{ say = "That code doesn't look right. Check my email and paste it again."; button = 'Unlock'; do = 'unlock'; note = 'It looks like GIGI-XXXX-XXXX.' } }
  }
}

function Get-FailLine([string]$title, [string]$detail) {
  $d = ($detail -replace [char]0x2014, ',' -replace [char]0x2013, ',').Trim()
  if ($d.Length -gt 160) { $d = $d.Substring($d.Length - 160) }
  @{ say = "$title didn't finish. Click Try again, or tell me what you see."; button = 'Try again'; do = 'retry'; note = $d }
}

function Get-FirstLine([bool]$resumed, [bool]$interview) {
  if ($resumed) { return "I'm back. Let's pick up where we left off." }
  $s = "Thank you. $Telepathic Now I'll set up your PC, one step at a time. I'll tell you whenever I need you."
  if (-not $interview) { $s += " For the bootcamp I'll get your PC ready: the kit install and the business interview happen at the bootcamp." }
  $s
}

$Say = @{
  claudeSignIn = 'I opened a PowerShell window and your browser. Sign in to Claude there and click Authorize. Claude in PowerShell needs its own sign in, even though the app is signed in.'
  gitHubSignIn = 'Now GitHub. I opened the page in your browser. Sign in if it asks, then paste this code there and click Authorize. I already copied it for you.'
  install      = 'Claude runs the kit install in the PowerShell window I opened, by itself. If it asks you anything, answer it there.'
  interview    = 'I opened the Claude app in your kit folder. Press Enter to start the setup, and give it a minute or two to wake up. Claude will interview you about your business. It takes about 25 minutes, and I''m right here.'
  claudeApp    = 'Sign in to the Claude app I just opened, with your email. Tell me when you''re in.'
  plan         = 'Do you have a paid Claude plan, like Pro or Max, and a GitHub account?'
  firstPrompt  = 'Last one. I asked your Claude what to focus on this week. Press Enter in the Claude app and read its answer. Did it name your own priorities?'
  toolsStatus  = "I'm adding Git, Python and GitHub's tool by myself. There's no window for this part, and nothing for you to do."
  signUpNote   = "HANDS: They need a GitHub account, so I opened GitHub's sign up page. Tell them it's free, and to come back and click I have both when it's made. If the page says access is restricted, or asks if they're human, tell them to press Control and R to refresh."
  boxLine      = 'Edge or Windows is asking permission. If it names Claude, PowerShell or Gigi, that''s part of setup: click Allow or Yes. Anything else, click No and tell me.'
  endedEarly   = 'That PowerShell window closed before it finished. Click Try again to run it again.'
  codeExpired  = 'That sign in ran out of time. Click Try again for a new code.'
}

function Get-AllLineText {
  $out = @($Telepathic)
  foreach ($l in $Lines.Values) { $out += $l.say; if ($l.note) { $out += $l.note } }
  foreach ($w in 'other_mac', 'on_hold', 'expired', 'offline', 'x') { $out += (Get-RedeemLine $w).say }
  $out += (Get-FailLine 'Step' 'detail').say
  $out += (Get-FirstLine $false $false)
  $out += $Say.Values
  $out
}
